namespace palisade::gui::layout::constraints {

int solve(int min, int max) {
    return (min + max) / 2;
}

}