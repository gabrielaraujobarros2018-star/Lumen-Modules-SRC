namespace palisade::gui::systemui {

int notifications() {
    return 0;
}

}