namespace palisade::gui::protocol::render {

int encode(int op) {
    return op + 100;
}

}