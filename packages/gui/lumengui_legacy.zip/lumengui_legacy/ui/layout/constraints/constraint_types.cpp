namespace palisade::gui::layout::constraints {

bool isFlexible(bool fixed) {
    return !fixed;
}

}