namespace palisade::gui::keyboard {

int translateKey(int raw) {
    return raw;
}

}