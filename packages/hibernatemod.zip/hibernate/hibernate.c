/**
 * hibernate.c - Lumen OS Hibernation Module
 * 
 * ARMv7a compatible hibernation state writer for Moto Nexus 6
 * Captures system state to /lumen-motonexus6/system/core/hibernate/data/hibernationstat.dat
 * Stores user data in /lumen-motonexus6/data/readonly/h/hibernat.USERDATA.readonly.dat
 * 
 * Author: Lumen OS Development Team
 * Target: Moto Nexus 6 (ARMv7a)
 * Version: 1.0.0
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <time.h>
#include <errno.h>
#include <signal.h>
#include <dirent.h>
#include <sys/sysinfo.h>
#include <linux/unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <curl/curl.h>
#include <sys/wait.h>

// Lumen OS specific includes
#include "lumen_defs.h"
#include "armv7a_utils.h"
#include "motonexus6_hw.h"

// Hibernation constants
#define HIBERNATION_MAGIC     0x4C554D454E  // "LUMEN"
#define HIBERNATION_VERSION   0x00010000    // 1.0
#define MAX_USERDATA_SIZE     (64 * 1024)   // 64KB
#define HIB_HEADER_SIZE       512
#define STATE_BUFFER_SIZE     (16 * 1024 * 1024) // 16MB
#define USERDATA_PATH_MAX     256
#define PROC_PATH_MAX         512

// File paths
#define HIBERNATION_STATE_PATH "/lumen-motonexus6/system/core/hibernate/data/hibernationstat.dat"
#define USERDATA_BASE_PATH     "/lumen-motonexus6/data/readonly/h"
#define USERDATA_FILE_PATTERN  "hibernat.%s.readonly.dat"

// Data structures
typedef struct {
    uint32_t magic;
    uint32_t version;
    uint64_t timestamp;
    uint32_t cpu_count;
    uint32_t total_memory;
    uint32_t used_memory;
    uint32_t free_memory;
    uint32_t uptime_seconds;
    uint32_t process_count;
    uint16_t screen_brightness;
    uint8_t battery_level;
    uint8_t thermal_state;
    uint8_t wifi_state;
    uint8_t bluetooth_state;
    uint32_t checksum;
    char kernel_version[128];
    char hostname[64];
} __attribute__((packed)) hibernation_header_t;

typedef struct {
    uint32_t pid;
    uint32_t uid;
    uint32_t state;
    uint64_t vsize;
    uint64_t rss;
    char comm[16];
    uint32_t priority;
    uint64_t utime;
    uint64_t stime;
} __attribute__((packed)) process_info_t;

static hibernation_header_t hib_header;
static char userdata_filename[USERDATA_PATH_MAX];
static uint8_t *state_buffer = NULL;
static uint32_t state_buffer_pos = 0;
static int hibernation_fd = -1;
static int userdata_fd = -1;

/**
 * Initialize hibernation buffer and paths
 */
static int init_hibernation(void) {
    struct sysinfo sysinfo;
    time_t now;
    
    // Initialize header
    memset(&hib_header, 0, sizeof(hib_header));
    hib_header.magic = HIBERNATION_MAGIC;
    hib_header.version = HIBERNATION_VERSION;
    time(&now);
    hib_header.timestamp = (uint64_t)now;
    
    // Get system info
    if (sysinfo(&sysinfo) == 0) {
        hib_header.total_memory = sysinfo.totalram * sysinfo.mem_unit / 1024;
        hib_header.free_memory = sysinfo.freeram * sysinfo.mem_unit / 1024;
        hib_header.uptime_seconds = sysinfo.uptime;
    }
    
    // Allocate state buffer
    state_buffer = malloc(STATE_BUFFER_SIZE);
    if (!state_buffer) {
        perror("Failed to allocate state buffer");
        return -1;
    }
    memset(state_buffer, 0, STATE_BUFFER_SIZE);
    state_buffer_pos = 0;
    
    // Create directories
    mkdir("/lumen-motonexus6/system/core/hibernate/data", 0755);
    mkdir("/lumen-motonexus6/data/readonly/h", 0755);
    
    return 0;
}

/**
 * Get current user identifier for userdata filename
 */
static int get_userdata_filename(void) {
    uid_t uid = getuid();
    snprintf(userdata_filename, USERDATA_PATH_MAX - 1,
             "%s/%s", USERDATA_BASE_PATH, 
             userdata_filename);
    return 0;
}

/**
 * Write data to hibernation state buffer
 */
static int write_to_buffer(const void *data, size_t size) {
    if (state_buffer_pos + size > STATE_BUFFER_SIZE) {
        return -1; // Buffer overflow
    }
    
    memcpy(state_buffer + state_buffer_pos, data, size);
    state_buffer_pos += size;
    return size;
}

/**
 * Capture process information from /proc
 */
static int capture_processes(void) {
    DIR *procdir;
    struct dirent *entry;
    char procpath[PROC_PATH_MAX];
    FILE *statfile;
    process_info_t proc_info;
    int count = 0;
    
    procdir = opendir("/proc");
    if (!procdir) {
        perror("Cannot open /proc");
        return -1;
    }
    
    hib_header.process_count = 0;
    
    while ((entry = readdir(procdir)) != NULL) {
        if (!isdigit(entry->d_name[0])) {
            continue;
        }
        
        snprintf(procpath, sizeof(procpath), "/proc/%s/stat", entry->d_name);
        statfile = fopen(procpath, "r");
        if (!statfile) {
            continue;
        }
        
        if (fscanf(statfile, "%u %15s %c %u %u %u %lu %lu %lu",
                   &proc_info.pid, proc_info.comm, 
                   (char*)&proc_info.state, &proc_info.uid,
                   &proc_info.vsize, &proc_info.rss,
                   &proc_info.utime, &proc_info.stime,
                   &proc_info.priority) == 9) {
            
            if (write_to_buffer(&proc_info, sizeof(process_info_t)) == sizeof(process_info_t)) {
                count++;
            }
        }
        
        fclose(statfile);
        if (count > 1024) break; // Limit processes
    }
    
    closedir(procdir);
    hib_header.process_count = count;
    return count;
}

/**
 * Capture ARMv7a specific CPU state
 */
static int capture_cpu_state(void) {
    uint32_t cpu_regs[8];
    int cpu_fd;
    
    // Read CPU info from debugfs (Moto Nexus 6 specific)
    cpu_fd = open("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq", O_RDONLY);
    if (cpu_fd >= 0) {
        char freq_buf[32];
        ssize_t bytes_read;
        
        bytes_read = read(cpu_fd, freq_buf, sizeof(freq_buf) - 1);
        if (bytes_read > 0) {
            freq_buf[bytes_read] = '';
            hib_header.cpu_count = 1; // Nexus 6 quad-core
            write_to_buffer(freq_buf, strlen(freq_buf));
        }
        close(cpu_fd);
    }
    
    // ARMv7a specific registers (simplified)
    cpu_regs[0] = armv7a_get_cpufreq();
    cpu_regs[1] = armv7a_get_temperature();
    cpu_regs[2] = motonexus6_get_battery_voltage();
    
    return write_to_buffer(cpu_regs, sizeof(cpu_regs));
}

/**
 * Capture user data from common locations
 */
static int capture_user_data(void) {
    char user_data[MAX_USERDATA_SIZE];
    int offset = 0;
    FILE *fp;
    
    // Capture current working directory
    if (getcwd(user_data + offset, MAX_USERDATA_SIZE - offset)) {
        size_t len = strlen(user_data + offset);
        offset += len + 1;
        write_to_buffer("CWD:", 4);
        write_to_buffer(user_data + offset - len - 1, len + 1);
    }
    
    // Capture environment variables (limited)
    char *env_path = getenv("PATH");
    if (env_path) {
        snprintf(user_data + offset, 256, "PATH:%s
", env_path);
        write_to_buffer(user_data + offset, strlen(user_data + offset));
    }
    
    // Capture shell history (if available)
    fp = fopen("/data/data/com.termux/files/home/.bash_history", "r");
    if (fp) {
        char line[256];
        while (fgets(line, sizeof(line), fp) && offset < MAX_USERDATA_SIZE - 256) {
            write_to_buffer(line, strlen(line));
        }
        fclose(fp);
    }
    
    return 0;
}

/**
 * Calculate and write header checksum
 */
static uint32_t calculate_checksum(void *data, size_t size) {
    uint32_t *ptr = (uint32_t*)data;
    uint32_t sum = 0;
    size_t i;
    
    for (i = 0; i < size / 4; i++) {
        sum ^= ptr[i];
    }
    return sum;
}

/**
 * Write hibernation header to file
 */
static int write_header(void) {
    // Get kernel version
    FILE *version_file = fopen("/proc/version", "r");
    if (version_file) {
        fgets(hib_header.kernel_version, sizeof(hib_header.kernel_version), version_file);
        fclose(version_file);
    }
    
    // Get hostname
    gethostname(hib_header.hostname, sizeof(hib_header.hostname));
    
    // Calculate checksum (excluding checksum field itself)
    uint32_t temp_checksum = hib_header.checksum;
    hib_header.checksum = 0;
    hib_header.checksum = calculate_checksum(&hib_header, sizeof(hib_header));
    
    // Write header
    if (write(hibernation_fd, &hib_header, sizeof(hib_header)) != sizeof(hib_header)) {
        perror("Failed to write header");
        return -1;
    }
    
    return 0;
}

/**
 * Main hibernation state capture function
 */
int lumen_hibernate_capture(void) {
    printf("[LUMEN] Starting hibernation state capture...
");
    
    // Initialize
    if (init_hibernation() != 0) {
        return -1;
    }
    
    // Get userdata filename
    get_userdata_filename();
    
    // Open files
    hibernation_fd = open(HIBERNATION_STATE_PATH, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (hibernation_fd < 0) {
        perror("Cannot open hibernation file");
        free(state_buffer);
        return -1;
    }
    
    userdata_fd = open(userdata_filename, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (userdata_fd < 0) {
        perror("Cannot open userdata file");
        close(hibernation_fd);
        free(state_buffer);
        return -1;
    }
    
    // Write header first
    if (write_header() != 0) {
        close(hibernation_fd);
        close(userdata_fd);
        free(state_buffer);
        return -1;
    }
    
    // Capture system state
    printf("[LUMEN] Capturing processes... ");
    capture_processes();
    printf("%u processes
", hib_header.process_count);
    
    printf("[LUMEN] Capturing CPU state... ");
    capture_cpu_state();
    printf("done
");
    
    printf("[LUMEN] Capturing user data... ");
    capture_user_data();
    printf("done
");
    
    // Write state buffer to hibernation file
    printf("[LUMEN] Writing %u bytes of state data... ", state_buffer_pos);
    if (write(hibernation_fd, state_buffer, state_buffer_pos) != state_buffer_pos) {
        perror("Failed to write state data");
        close(hibernation_fd);
        close(userdata_fd);
        free(state_buffer);
        return -1;
    }
    printf("done
");
    
    // Write userdata to separate file
    if (write(userdata_fd, state_buffer, state_buffer_pos) != state_buffer_pos) {
        perror("Failed to write userdata");
    }
    
    // Cleanup
    close(hibernation_fd);
    close(userdata_fd);
    free(state_buffer);
    
    printf("[LUMEN] Hibernation state saved successfully
");
    printf("[LUMEN] Main state: %s
", HIBERNATION_STATE_PATH);
    printf("[LUMEN] Userdata: %s
", userdata_filename);
    
    return 0;
}

/**
 * Verify hibernation file integrity
 */
int lumen_hibernate_verify(const char *hib_file) {
    hibernation_header_t header;
    int fd;
    uint32_t calc_checksum;
    
    fd = open(hib_file, O_RDONLY);
    if (fd < 0) {
        perror("Cannot open hibernation file for verification");
        return -1;
    }
    
    if (read(fd, &header, sizeof(header)) != sizeof(header)) {
        perror("Cannot read header");
        close(fd);
        return -1;
    }
    
    calc_checksum = header.checksum;
    header.checksum = 0;
    if (calculate_checksum(&header, sizeof(header)) != calc_checksum) {
        printf("[LUMEN] Checksum mismatch!
");
        close(fd);
        return -1;
    }
    
    printf("[LUMEN] Hibernation file verified OK
");
    printf("  Magic: 0x%08X
", header.magic);
    printf("  Version: 0x%08X
", header.version);
    printf("  Timestamp: %llu
", header.timestamp);
    printf("  Processes: %u
", header.process_count);
    
    close(fd);
    return 0;
}

/**
 * Cleanup signal handler
 */
static void cleanup_handler(int sig) {
    if (state_buffer) free(state_buffer);
    if (hibernation_fd >= 0) close(hibernation_fd);
    if (userdata_fd >= 0) close(userdata_fd);
    exit(1);
}

/**
 * Main entry point
 */
int main(int argc, char *argv[]) {
    int ret = 0;
    
    // Install signal handlers
    signal(SIGINT, cleanup_handler);
    signal(SIGTERM, cleanup_handler);
    
    if (argc > 1 && strcmp(argv[1], "verify") == 0) {
        if (argc > 2) {
            ret = lumen_hibernate_verify(argv[2]);
        } else {
            ret = lumen_hibernate_verify(HIBERNATION_STATE_PATH);
        }
    } else {
        ret = lumen_hibernate_capture();
    }
    
    return ret;
}

// ARMv7a specific utility functions (stubs for your project)
uint32_t armv7a_get_cpufreq(void) {
    return 2265000; // 2.265 GHz (Nexus 6 max)
}

uint32_t armv7a_get_temperature(void) {
    return 45; // 45°C
}

uint32_t motonexus6_get_battery_voltage(void) {
    return 4100; // 4.1V typical
}

// ---- Data Transferring ----

/**
 * DATA TRANSFER MODULE - Appended to hibernate.c
 * Network transfer capabilities for hibernation data
 * Supports: Local sync, ADB push, HTTP POST, FTP upload
 */

// Transfer constants
#define TRANSFER_BUFFER_SIZE   (1 * 1024 * 1024)  // 1MB chunks
#define LUMEN_SYNC_SERVER      "lumen-sync.lumen-os.local"
#define ADB_PUSH_TIMEOUT       30
#define HTTP_UPLOAD_TIMEOUT    120
#define MAX_TRANSFER_RETRIES   3

// Transfer configuration structure
typedef struct {
    char source_file[512];
    char dest_path[512];
    char transfer_method[32];
    char server_host[256];
    int  server_port;
    char username[64];
    char password[64];
    int  chunk_size;
    int  retries;
} transfer_config_t;

static transfer_config_t transfer_config;
static CURL *curl_handle = NULL;

/**
 * Initialize CURL for HTTP/FTP transfers
 */
static int init_curl_transfer(void) {
    curl_global_init(CURL_GLOBAL_DEFAULT);
    curl_handle = curl_easy_init();
    if (!curl_handle) {
        return -1;
    }
    
    curl_easy_setopt(curl_handle, CURLOPT_TIMEOUT, HTTP_UPLOAD_TIMEOUT);
    curl_easy_setopt(curl_handle, CURLOPT_CONNECTTIMEOUT, 10);
    curl_easy_setopt(curl_handle, CURLOPT_FOLLOWLOCATION, 1L);
    curl_easy_setopt(curl_handle, CURLOPT_NOSIGNAL, 1L);
    
    return 0;
}

/**
 * Transfer progress callback
 */
static int transfer_progress(void *clientp, 
                           curl_off_t dltotal, curl_off_t dlnow,
                           curl_off_t ultotal, curl_off_t ulnow) {
    if (ultotal > 0) {
        int percent = (int)((ulnow * 100) / ultotal);
        printf("
[TRANSFER] %d%% (%ld/%ld bytes)", 
               percent, (long)ulnow, (long)ultotal);
        fflush(stdout);
    }
    return 0;
}

/**
 * Method 1: Local file copy with progress
 */
static int transfer_local_copy(const char *src, const char *dest) {
    int src_fd, dest_fd;
    uint8_t *buffer;
    ssize_t bytes_read, bytes_written;
    off_t total_read = 0;
    struct stat st;
    
    if (stat(src, &st) != 0) {
        perror("Source file stat failed");
        return -1;
    }
    
    printf("[TRANSFER] Local copy: %s -> %s (%ld bytes)
", src, dest, st.st_size);
    
    buffer = malloc(TRANSFER_BUFFER_SIZE);
    if (!buffer) {
        return -1;
    }
    
    src_fd = open(src, O_RDONLY);
    dest_fd = open(dest, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    
    if (src_fd < 0 || dest_fd < 0) {
        perror("Cannot open transfer files");
        free(buffer);
        return -1;
    }
    
    while ((bytes_read = read(src_fd, buffer, TRANSFER_BUFFER_SIZE)) > 0) {
        bytes_written = write(dest_fd, buffer, bytes_read);
        if (bytes_written != bytes_read) {
            perror("Write error during local copy");
            break;
        }
        total_read += bytes_read;
        printf("
[LOCAL] %ld/%ld bytes (%.1f%%)", 
               total_read, st.st_size, 
               (total_read * 100.0) / st.st_size);
        fflush(stdout);
    }
    
    printf("
[LOCAL] Transfer complete
");
    close(src_fd);
    close(dest_fd);
    free(buffer);
    return 0;
}

/**
 * Method 2: ADB push to connected host
 */
static int transfer_adb_push(const char *src_file) {
    char cmd[1024];
    int status, retry;
    
    printf("[TRANSFER] ADB push: %s
", src_file);
    
    for (retry = 0; retry < MAX_TRANSFER_RETRIES; retry++) {
        snprintf(cmd, sizeof(cmd), 
                "adb push "%s" /sdcard/lumen-hibernate/ && "
                "adb shell 'chmod 644 /sdcard/lumen-hibernate/%s'", 
                src_file, basename(src_file));
        
        status = system(cmd);
        if (WEXITSTATUS(status) == 0) {
            printf("[ADB] Successfully pushed to /sdcard/lumen-hibernate/
");
            return 0;
        }
        
        printf("[ADB] Retry %d/%d failed (code %d)
", retry+1, MAX_TRANSFER_RETRIES, WEXITSTATUS(status));
        sleep(2);
    }
    
    return -1;
}

/**
 * Method 3: HTTP POST upload
 */
static size_t write_callback(void *contents, size_t size, size_t nmemb, void *userp) {
    return size * nmemb;
}

static int transfer_http_post(const char *src_file) {
    CURLcode res;
    struct curl_slist *headers = NULL;
    FILE *file_stream;
    char url[512];
    
    snprintf(url, sizeof(url), "http://%s:%d/api/hibernation/upload", 
             transfer_config.server_host, transfer_config.server_port);
    
    file_stream = fopen(src_file, "rb");
    if (!file_stream) {
        perror("Cannot open file for HTTP upload");
        return -1;
    }
    
    curl_easy_setopt(curl_handle, CURLOPT_URL, url);
    curl_easy_setopt(curl_handle, CURLOPT_UPLOAD, 1L);
    curl_easy_setopt(curl_handle, CURLOPT_READFUNCTION, NULL);
    curl_easy_setopt(curl_handle, CURLOPT_READDATA, file_stream);
    curl_easy_setopt(curl_handle, CURLOPT_INFILESIZE_LARGE, 0);
    curl_easy_setopt(curl_handle, CURLOPT_PROGRESSFUNCTION, transfer_progress);
    curl_easy_setopt(curl_handle, CURLOPT_PROGRESSDATA, NULL);
    curl_easy_setopt(curl_handle, CURLOPT_WRITEFUNCTION, write_callback);
    
    headers = curl_slist_append(headers, "Content-Type: application/octet-stream");
    headers = curl_slist_append(headers, "X-LumenOS: 1.0");
    curl_easy_setopt(curl_handle, CURLOPT_HTTPHEADER, headers);
    
    printf("[HTTP] Uploading to %s...
", url);
    res = curl_easy_perform(curl_handle);
    
    curl_slist_free_all(headers);
    fclose(file_stream);
    
    if (res != CURLE_OK) {
        printf("
[HTTP] Upload failed: %s
", curl_easy_strerror(res));
        return -1;
    }
    
    printf("
[HTTP] Upload successful
");
    return 0;
}

/**
 * Method 4: FTP upload
 */
static int transfer_ftp_upload(const char *src_file) {
    CURLcode res;
    FILE *file_stream;
    char url[512];
    
    snprintf(url, sizeof(url), "ftp://%s:%d%s", 
             transfer_config.server_host, 
             transfer_config.server_port,
             transfer_config.dest_path);
    
    file_stream = fopen(src_file, "rb");
    if (!file_stream) {
        return -1;
    }
    
    curl_easy_setopt(curl_handle, CURLOPT_URL, url);
    curl_easy_setopt(curl_handle, CURLOPT_UPLOAD, 1L);
    curl_easy_setopt(curl_handle, CURLOPT_READDATA, file_stream);
    curl_easy_setopt(curl_handle, CURLOPT_INFILESIZE_LARGE, 0);
    curl_easy_setopt(curl_handle, CURLOPT_USERNAME, transfer_config.username);
    curl_easy_setopt(curl_handle, CURLOPT_PASSWORD, transfer_config.password);
    
    printf("[FTP] Uploading to %s...
", url);
    res = curl_easy_perform(curl_handle);
    fclose(file_stream);
    
    if (res != CURLE_OK) {
        printf("
[FTP] Upload failed: %s
", curl_easy_strerror(res));
        return -1;
    }
    
    printf("
[FTP] Upload successful
");
    return 0;
}

/**
 * Auto-detect best transfer method
 */
static int auto_detect_transfer_method(void) {
    // Check if ADB is available
    if (system("adb devices | grep -q device") == 0) {
        strcpy(transfer_config.transfer_method, "adb");
        printf("[TRANSFER] Detected ADB connection
");
        return 0;
    }
    
    // Check network connectivity
    if (system("ping -c 1 8.8.8.8 > /dev/null 2>&1") == 0) {
        strcpy(transfer_config.transfer_method, "http");
        strcpy(transfer_config.server_host, LUMEN_SYNC_SERVER);
        transfer_config.server_port = 8080;
        printf("[TRANSFER] Network available, using HTTP
");
        return 0;
    }
    
    // Default to local
    strcpy(transfer_config.transfer_method, "local");
    strcpy(transfer_config.dest_path, "/lumen-motonexus6/backup/hibernation/");
    printf("[TRANSFER] Using local copy
");
    return 0;
}

/**
 * Execute data transfer
 */
static int execute_data_transfer(const char *hib_file, const char *userdata_file) {
    int ret = 0;
    
    printf("
=== LUMEN OS DATA TRANSFER ===
");
    
    // Auto-configure
    if (auto_detect_transfer_method() != 0) {
        printf("[TRANSFER] No suitable method detected, skipping
");
        return 0;
    }
    
    // Local copy first (always safe)
    snprintf(transfer_config.source_file, sizeof(transfer_config.source_file), 
             "%s", hib_file);
    snprintf(transfer_config.dest_path, sizeof(transfer_config.dest_path),
             "/lumen-motonexus6/backup/hibernation/%s", 
             basename((char*)hib_file));
    
    if (transfer_local_copy(hib_file, transfer_config.dest_path) != 0) {
        printf("[LOCAL] Backup failed
");
        ret = -1;
    }
    
    // Method-specific transfers
    if (strcmp(transfer_config.transfer_method, "adb") == 0) {
        if (transfer_adb_push(hib_file) != 0) ret = -1;
        if (transfer_adb_push(userdata_file) != 0) ret = -1;
    }
    else if (strcmp(transfer_config.transfer_method, "http") == 0) {
        if (init_curl_transfer() == 0) {
            snprintf(transfer_config.dest_path, sizeof(transfer_config.dest_path),
                    "/upload/hibernationstat.dat");
            if (transfer_http_post(hib_file) != 0) ret = -1;
            
            snprintf(transfer_config.dest_path, sizeof(transfer_config.dest_path),
                    "/upload/hibernat.USERDATA.readonly.dat");
            if (transfer_http_post(userdata_file) != 0) ret = -1;
            
            curl_easy_cleanup(curl_handle);
        }
    }
    else if (strcmp(transfer_config.transfer_method, "ftp") == 0) {
        if (init_curl_transfer() == 0) {
            if (transfer_ftp_upload(hib_file) != 0) ret = -1;
            if (transfer_ftp_upload(userdata_file) != 0) ret = -1;
            curl_easy_cleanup(curl_handle);
        }
    }
    
    printf("
[TRANSFER] All transfers completed (status: %s)
", 
           ret == 0 ? "SUCCESS" : "FAILED");
    
    return ret;
}

/**
 * Updated main function with transfer support
 */
int main(int argc, char *argv[]) {
    int ret = 0;
    char *hib_file = HIBERNATION_STATE_PATH;
    char *userdata_file = userdata_filename;
    
    // Install signal handlers
    signal(SIGINT, cleanup_handler);
    signal(SIGTERM, cleanup_handler);
    
    if (argc > 1 && strcmp(argv[1], "verify") == 0) {
        if (argc > 2) {
            ret = lumen_hibernate_verify(argv[2]);
        } else {
            ret = lumen_hibernate_verify(HIBERNATION_STATE_PATH);
        }
    } else {
        // Capture hibernation state
        ret = lumen_hibernate_capture();
        if (ret == 0) {
            // Execute data transfer
            ret = execute_data_transfer(hib_file, userdata_file);
        }
    }
    
    // Cleanup CURL if initialized
    if (curl_handle) {
        curl_easy_cleanup(curl_handle);
        curl_global_cleanup();
    }
    
    return ret;
}

/*
Usage Example:

# Capture hibernation state
./hibernate

# Verify saved state  
./hibernate verify
*/
