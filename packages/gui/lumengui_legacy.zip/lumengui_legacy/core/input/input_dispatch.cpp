#include "input_dispatch.hpp"

namespace palisade::gui::input {

void dispatchInput(int device, int code) {
    (void)device;
    (void)code;
}

}