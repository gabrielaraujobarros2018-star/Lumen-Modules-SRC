namespace palisade::gui::mouse {

static bool left;

void setLeft(bool v) {
    left = v;
}

}