namespace palisade::gui::systemui {

void toggle() {}

}