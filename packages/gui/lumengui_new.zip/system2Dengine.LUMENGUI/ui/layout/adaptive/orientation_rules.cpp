namespace palisade::gui::layout::adaptive {

bool allowRotation(int classId) {
    return classId != 0;
}

}