namespace palisade::gui::lang::en_us {

const char* error() { return "Error"; }

}