namespace palisade::gui::protocol::window {

bool focused() {
    return true;
}

}