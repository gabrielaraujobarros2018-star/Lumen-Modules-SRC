namespace palisade::gui::security {

bool strict() {
    return true;
}

}