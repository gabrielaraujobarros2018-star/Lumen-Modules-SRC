namespace palisade::gui::platform::mobile {

int filter(int v) {
    return v / 2;
}

}