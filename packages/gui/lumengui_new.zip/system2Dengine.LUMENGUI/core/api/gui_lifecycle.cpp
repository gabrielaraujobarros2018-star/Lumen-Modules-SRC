namespace palisade::gui::api {

bool isGuiReady() {
    return true;
}

}