namespace palisade::gui::mouse {

void scroll(int delta) {
    (void)delta;
}

}