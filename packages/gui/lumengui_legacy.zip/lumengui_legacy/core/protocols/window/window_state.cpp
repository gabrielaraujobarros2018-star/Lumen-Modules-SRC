namespace palisade::gui::protocol::window {

static bool active = false;

void set(bool v) {
    active = v;
}

}