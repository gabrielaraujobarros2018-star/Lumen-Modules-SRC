CD /D %~dp0
dir
pause