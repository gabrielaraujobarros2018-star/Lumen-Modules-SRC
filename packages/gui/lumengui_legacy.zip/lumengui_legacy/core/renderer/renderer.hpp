#pragma once

namespace palisade::gui::renderer {

void beginFrame();
void endFrame();

}