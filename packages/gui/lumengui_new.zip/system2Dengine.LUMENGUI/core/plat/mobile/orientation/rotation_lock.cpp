namespace palisade::gui::platform::mobile {

static bool locked = false;

void lock(bool v) {
    locked = v;
}

}