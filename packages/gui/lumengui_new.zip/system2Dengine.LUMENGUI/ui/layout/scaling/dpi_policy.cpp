namespace palisade::gui::layout::scaling {

float dpiFactor(int dpi) {
    return dpi / 160.0f;
}

}