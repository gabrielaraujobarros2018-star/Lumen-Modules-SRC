namespace palisade::gui::platform::mobile {

void notifyChange() {}

}