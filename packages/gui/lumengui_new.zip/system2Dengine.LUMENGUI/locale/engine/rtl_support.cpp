namespace palisade::gui::locale {

bool isRTL(int lang) {
    return lang == 2;
}

}