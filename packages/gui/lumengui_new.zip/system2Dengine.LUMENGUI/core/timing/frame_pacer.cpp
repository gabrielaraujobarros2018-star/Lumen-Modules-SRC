namespace palisade::gui::time {

bool shouldRender() {
    return true;
}

}