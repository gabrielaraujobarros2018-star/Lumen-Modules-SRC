namespace palisade::gui::render::framebuffer {

void clear(int color) {
    (void)color;
}

}