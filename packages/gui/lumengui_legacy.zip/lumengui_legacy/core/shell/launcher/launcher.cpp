namespace palisade::gui::shell {

void launch(int app) {
    (void)app;
}

}