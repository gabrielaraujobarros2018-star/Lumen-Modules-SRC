namespace palisade::gui::mouse {

void onMove(int x, int y) {
    (void)x;
    (void)y;
}

}