namespace palisade::gui::render::software {

void flush() {}

}