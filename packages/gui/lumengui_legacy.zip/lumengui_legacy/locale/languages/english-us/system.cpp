namespace palisade::gui::lang::en_us {

const char* system() { return "System"; }

}