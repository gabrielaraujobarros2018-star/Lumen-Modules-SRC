namespace palisade::gui::platform::mobile {

int readSensor(int id) {
    return id * 10;
}

}