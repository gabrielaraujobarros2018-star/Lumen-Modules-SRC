namespace palisade::gui::platform::mobile {

static int last = 0;

void store(int v) {
    last = v;
}

}