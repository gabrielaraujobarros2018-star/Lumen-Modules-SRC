// main.rs - Lumen OS IPC Main for Nexus 6 (shamu, ARMv7a)
// Full IPC server with IpcPagingHandler, IpcTargetingControl integration.
// 16kb paging, UID enforcement, Binder transactions for Lumen OS.

#![no_std]
#![no_main]
#![feature(asm, panic_info_message, alloc_error_handler)]

extern crate alloc;
use core::alloc::Layout;
use core::panic::PanicInfo;
use core::ptr;
use alloc::boxed::Box;
use alloc::vec::Vec;

mod handler;
use handler::{IpcPagingHandler, ipc_paging_handler_init};

const MEM_PAGE_SIZE: usize = 16 * 1024;
const MAX_BINDER_TXN: usize = 1024 * 1024;  // 1MB max transaction
const KERNEL_BASE: usize = 0x8000_0000;
const SYSTEM_UID: u32 = 1000;

#[repr(C)]
struct BinderState {
    magic: u32,
    handle: u32,
    uid: u32,
    target: [u8; 64],
    data_len: usize,
    pages_mapped: usize,
}

#[repr(C)]
struct BinderTransaction {
    code: u32,
    flags: u32,
    data: *mut u8,
    data_size: usize,
    target_handle: u32,
}

static mut IPC_HANDLER: Option<*mut IpcPagingHandler> = None;
static mut IPC_STATE: Option<BinderState> = None;

#[no_mangle]
pub extern "C" fn main(_argc: isize, _argv: *const *const u8) -> isize {
    unsafe {
        // Initialize paging handler
        ipc_paging_handler_init();
        
        // Setup IPC state
        let mut state = Box::new(BinderState {
            magic: 0x4C495043,  // "LIPC"
            handle: 0,
            uid: SYSTEM_UID,
            target: *b"Motorola Nexus 6 shamu",
            data_len: 0,
            pages_mapped: 0,
        });
        IPC_STATE = Some(Box::into_raw(state));
        
        lumen_ipc_main_loop();
    }
    0
}

#[no_mangle]
pub extern "C" fn lumen_ipc_service_handler(txn: *mut BinderTransaction) -> i32 {
    unsafe {
        let txn = &*txn;
        if txn.code == 0 { return binder_driver_return(0); }
        
        let state = IPC_STATE.as_ref().unwrap();
        if state.uid != SYSTEM_UID {
            return binder_driver_return(-1);  // UID enforcement
        }
        
        let data_slice = core::slice::from_raw_parts(txn.data, txn.data_size);
        match IPC_HANDLER.as_ref().unwrap().as_ref().unwrap().handle_transaction(
            state.uid, 
            core::str::from_utf8(&state.target).unwrap_or("unknown"), 
            data_slice
        ) {
            Ok(()) => {
                state.data_len = txn.data_size;
                binder_driver_return(0)
            }
            Err(_) => binder_driver_return(-13),  // EACCES
        }
    }
}

unsafe fn lumen_ipc_main_loop() {
    loop {
        // Poll Nexus 6 binder driver (/dev/binder)
        let txn = binder_poll_transaction();
        if !txn.is_null() {
            let result = lumen_ipc_service_handler(txn);
            binder_complete_transaction(txn, result);
        }
        
        cortex_a15_wfi();  // ARMv7-A idle
    }
}

#[inline(always)]
unsafe fn binder_poll_transaction() -> *mut BinderTransaction {
    // Nexus 6 binder driver ioctl(BR_POLL_TRANSACTION)
    extern "C" {
        fn ioctl_binder_poll() -> *mut BinderTransaction;
    }
    ioctl_binder_poll()
}

#[inline(always)]
unsafe fn binder_complete_transaction(txn: *mut BinderTransaction, result: i32) {
    // binder driver ioctl(BR_TRANSACTION_COMPLETE)
    core::arch::asm!(
        "mov r0, {txn}",
        "mov r1, {result}",
        "bl ioctl_binder_complete",
        txn = in(reg) txn as u32,
        result = in(reg) result as u32,
        options(nostack)
    );
}

#[inline(always)]
fn binder_driver_return(code: i32) -> i32 {
    // Return to binder driver with status
    core::arch::asm!(
        "mov r0, {code}",
        "bx lr",
        code = in(reg) code as u32,
        options(nostack)
    );
    code
}

#[naked]
#[no_mangle]
pub unsafe extern "C" fn cortex_a15_wfi() {
    asm!(
        "wfi",
        "bx lr",
        options(nostack)
    );
}

/// Kernel panic handler for Lumen OS
#[panic_handler]
fn panic(_info: &PanicInfo) -> ! {
    loop {
        unsafe {
            core::arch::asm!("wfi", options(nostack));
        }
    }
}

#[alloc_error_handler]
fn alloc_error_handler(_layout: Layout) -> ! {
    panic!("allocation error")
}

/// ARMv7-A page table management for IPC pages
pub unsafe fn map_ipc_region_16kb(
    virt: usize, 
    phys: usize, 
    pages: usize,
    cache_flags: u32
) -> bool {
    let l1_base = (KERNEL_BASE + 0x4000) as *mut u32;
    
    for i in 0..pages {
        let vaddr = virt + i * MEM_PAGE_SIZE;
        let idx = (vaddr >> 20) as usize;  // 1MB section index
        
        let section = (phys + i * MEM_PAGE_SIZE) as u32
            | 1  // Section type
            | (cache_flags << 2)  // TEX/C/B
            | (1 << 4);  // AP full access
        
        *l1_base.add(idx) = section;
        
        // TLB maintenance (Nexus 6 Cortex-A15)
        core::arch::asm!(
            "mcr p15, 0, {0}, c7, c5, 1",  // TLBIALL
            "dsb",
            "isb",
            in(reg) vaddr as u32 >> 20,
            options(nostack)
        );
    }
    true
}

/// Global IPC lock (from config "Lock": "Global")
pub struct GlobalIpcLock;
unsafe impl Sync for GlobalIpcLock {}

impl GlobalIpcLock {
    pub const fn new() -> Self { Self }
    
    pub fn lock(&self) {
        unsafe {
            core::arch::asm!(
                "1: ldrex r0, [r7]",
                "teq r0, #0",
                "wfene",
                "bne 1b",
                "strex r0, r1, [r7]",
                "teq r0, #0",
                "bne 1b",
                options(nostack)
            );
        }
    }
    
    pub fn unlock(&self) {
        unsafe {
            core::arch::asm!(
                "mov r0, #0",
                "str r0, [r7]",
                "dsb",
                "sev",
                options(nostack)
            );
        }
    }
}

/// Nexus 6 specific: MSM8994 binder driver integration
#[no_mangle]
pub extern "C" fn lumen_ipc_register_service() {
    unsafe {
        // Register with /dev/binder
        core::arch::asm!(
            "mov r0, #1",           // BINDER_SET_CONTEXT_MGR
            "mov r1, #0",
            "mov r2, #0",
            "mov r7, #5",           // SYS_IOCTL
            "svc #0",
            options(nostack)
        );
    }
}