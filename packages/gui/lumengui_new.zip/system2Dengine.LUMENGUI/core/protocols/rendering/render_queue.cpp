namespace palisade::gui::protocol::render {

static int q = 0;

void push() {
    q++;
}

}