#pragma once
#include <stdint.h>

namespace palisade::gui::scene {

struct Node {
    uint64_t id;
    int x, y;
};

}