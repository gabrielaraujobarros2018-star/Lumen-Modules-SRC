#pragma once
#include <stdint.h>

namespace palisade::gui::time {

uint64_t now();

}