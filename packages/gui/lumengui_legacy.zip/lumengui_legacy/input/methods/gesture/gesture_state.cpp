namespace palisade::gui::gesture {

static bool active = false;

void setActive(bool v) {
    active = v;
}

}