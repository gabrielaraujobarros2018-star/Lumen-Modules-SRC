namespace palisade::gui::shell {

int apps() {
    return 5;
}

}