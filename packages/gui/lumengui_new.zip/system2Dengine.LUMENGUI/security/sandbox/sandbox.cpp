namespace palisade::gui::security {

bool allowed(int id) {
    return id >= 0;
}

}