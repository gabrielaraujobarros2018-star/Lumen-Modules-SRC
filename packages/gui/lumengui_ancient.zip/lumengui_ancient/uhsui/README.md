# Universal Hybrid System UI

A **single, compilable, system-level UI framework** that renders identically on **phones and desktops**, while adapting layout mechanics per device.  
This project defines **system UI only** (no apps) and implements **30 shared system screens** rendered through a **device-aware layout adapter**.

The result is one UI identity, one logic layer, one render pipeline — two form factors.

---

## Core Idea

**Universality without compromise**

- Same colors, shadows, depth, lighting, motion, typography
- Same screen registry and routing logic
- Same rendering engine and shaders
- Same interaction primitives

Only the **layout skeleton** adapts:
- Phone → gesture-first, low column density
- Desktop → pointer-first, high column density

No forks. No duplicated screens. No responsive hacks.

---

## What This Is (and Is Not)

### This IS
- A system UI framework
- Engine-level architecture
- Compilable C++ UI core
- Screen-based OS navigation
- Shared visual physics model
- Deterministic layout adaptation

### This is NOT
- An app framework
- A mockup or design file
- A theme pack
- A responsive web UI
- A widget collection

---

## Screen Coverage

The system defines **30 core system screens**, shared by both phone and desktop:

1. Boot  
2. Lock  
3. Authentication  
4. Home  
5. App Drawer  
6. Task Switcher  
7. Notifications  
8. Quick Controls  
9. Settings Root  
10. Display  
11. Sound  
12. Network  
13. Battery  
14. Storage  
15. Privacy  
16. Security  
17. Accounts  
18. Accessibility  
19. Developer  
20. Updates  
21. About  
22. File Manager  
23. System Monitor  
24. Power Menu  
25. Multi-Window Manager  
26. Input Manager  
27. Theme Manager  
28. Backup  
29. Restore  
30. Shutdown  

Each screen:
- Exists once
- Is registered once
- Can navigate to any other screen
- Renders through the same renderer
- Adapts layout automatically

---

## Layout Adaptation Model

### Shared UI Characteristics
- Soft matte surfaces
- Rounded geometry
- Layered elevation
- Physical shadow rules
- Directional sunlight lighting
- Motion based on mass, not speed

### Phone Layout Adapter
- 4-column grid
- Large hit targets
- Gesture navigation
- Edge-anchored sheets
- Bottom dock emphasis

### Desktop Layout Adapter
- 12-column grid
- Pointer hover elevation
- Persistent panels
- Keyboard focus rings
- Flexible dock placement

The **screen code never changes** — only layout metrics do.

---

## Visual Systems

### Color System
- Neutral surfaces
- High-contrast text
- Single accent color
- No per-device overrides

### Depth & Shadows
- Elevation-based shadow physics
- Consistent blur and offset scaling
- No flat UI modes

### Sunlight Shader
- Single global light source
- Directional shading
- Subtle warmth
- Shared across all screens and devices

---

## Navigation & Routing

- All screens are registered at startup
- Navigation handled by a central router
- Screens can call each other freely
- Entry and exit hooks supported
- No device-specific routing logic

---

## Compilation & Execution

- Standard C++ project
- Engine initializes device profile
- Layout adapter selected at runtime
- Screens render based on adapter metrics
- Visual systems applied globally

---

## Design Goals

- Zero duplication
- Predictable behavior
- System-level seriousness
- Long-term maintainability
- Device independence
- Visual consistency across form factors

---

## Philosophy

This UI treats **phones and desktops as equal citizens**, not scaled versions of each other.  
It avoids trends, avoids per-device redesigns, and avoids aesthetic fragmentation.

The interface behaves like a **physical system**, not a collection of screens.

---

## Status

- Architecture defined
- Screen registry scalable
- Layout adapters implemented
- Visual systems unified
- Ready for expansion into a full OS shell

---

## License

Intended for experimental OS, shell, or research use.  
No guarantees. No magic. Just structure.