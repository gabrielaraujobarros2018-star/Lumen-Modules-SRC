namespace palisade::gui::protocol::input {

bool valid(int p) {
    return p >= 0;
}

}