#include <animation.h>

float anim_slide(float t) {
    return t * t;
}