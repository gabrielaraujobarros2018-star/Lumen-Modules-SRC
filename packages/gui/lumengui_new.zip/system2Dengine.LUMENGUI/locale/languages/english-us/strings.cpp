namespace palisade::gui::lang::en_us {

const char* ok() { return "OK"; }
const char* cancel() { return "Cancel"; }

}