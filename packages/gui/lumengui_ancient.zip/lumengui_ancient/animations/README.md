# PalisadeOS – Animations Pack

This folder contains the **core UI and system animations** used by PalisadeOS.  
All animations are designed to be lightweight, consistent, and hardware-friendly, prioritizing smoothness over excess visual noise.

The goal is to give PalisadeOS a **calm, tactile, and modern feel** while keeping performance predictable across devices.

---

## Design Principles

- **Minimal motion**: animations communicate state, not distraction  
- **Short duration**: most animations complete within 0.8–1.2 seconds  
- **Consistent easing**: unified timing curves across the system  
- **Vector-first**: scalable visuals for all screen sizes  
- **Low GPU load**: safe for low-end and mobile hardware

---

## Included Animations

### 1. Boot Sequence
System startup animation with logo fade-in and progress pulse.  
Used during early boot and cold starts.

### 2. Lockscreen Pulse
Soft ambient glow behind the lockscreen indicator.  
Provides life without drawing attention.

### 3. Notification Swipe
Slide-in and slide-out animation for notifications.  
Clear directionality and fast response.

### 4. App Launch Bloom
Radial bloom from the touch point when launching apps.  
Enhances touch feedback and spatial awareness.

### 5. Task Switch Flip
Card-style flip transition between running applications.  
Light 3D effect with minimal depth.

### 6. Volume Slider Wave
Waveform ripple synced to volume level changes.  
Visualizes audio interaction intuitively.

### 7. Error Shake
Subtle horizontal shake for invalid actions or inputs.  
Non-intrusive but immediately understandable.

### 8. Network Connect Spin
Looping circular indicator for network connection states.  
Automatically stops on success or failure.

### 9. Dark Mode Fade
Crossfade transition between light and dark themes.  
Prevents harsh contrast jumps.

### 10. Shutdown Fadeout
Smooth fade-to-black animation for shutdown and reboot.  
Creates a clean system exit.

---

## Performance Notes

- Target frame rate: **24–30 FPS**
- Avoid stacking multiple animations simultaneously
- Prefer opacity, transform, and scale over blur or heavy filters
- Animations should degrade gracefully if skipped or interrupted

---

## Usage Philosophy

Animations in PalisadeOS are **functional UI components**, not decorations.  
If an animation does not clarify state, feedback, or transition, it should not exist.

This pack represents the baseline animation language of the system and should remain stylistically consistent across future additions.

---

PalisadeOS UI Motion System  
Clean. Calm. Intentional.