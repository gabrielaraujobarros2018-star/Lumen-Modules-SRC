namespace palisade::gui::locale {

const char* lookup(int id) {
    return (id == 0) ? "OK" : "UNKNOWN";
}

}