#include "compositor.hpp"

namespace palisade::gui::compositor {

void submitLayer(uint64_t surfaceId) {
    (void)surfaceId;
}

void composeFrame() {
    // Ordered composition pass
}

}