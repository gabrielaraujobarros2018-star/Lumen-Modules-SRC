#pragma once

namespace palisade::gui::input {

void dispatchInput(int device, int code);

}