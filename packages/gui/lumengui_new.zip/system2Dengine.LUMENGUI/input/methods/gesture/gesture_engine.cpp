namespace palisade::gui::gesture {

void processSwipe(int dx, int dy) {
    (void)dx;
    (void)dy;
}

}