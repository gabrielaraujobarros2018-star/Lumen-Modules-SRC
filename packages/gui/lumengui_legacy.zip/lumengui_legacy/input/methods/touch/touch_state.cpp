namespace palisade::gui::touch {

static int fingers = 0;

void setFingers(int c) {
    fingers = c;
}

}