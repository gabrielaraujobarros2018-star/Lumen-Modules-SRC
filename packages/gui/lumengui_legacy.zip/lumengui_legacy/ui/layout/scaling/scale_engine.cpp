namespace palisade::gui::layout::scaling {

float scale(float value, float factor) {
    return value * factor;
}

}