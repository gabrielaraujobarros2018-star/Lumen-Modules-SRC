namespace palisade::gui::touch {

void onTouch(int x, int y) {
    (void)x;
    (void)y;
}

}