namespace palisade::gui::keyboard {

bool shouldRepeat(int key) {
    return key != 0;
}

}