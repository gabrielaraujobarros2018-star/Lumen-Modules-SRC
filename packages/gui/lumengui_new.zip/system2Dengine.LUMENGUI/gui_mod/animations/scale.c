#include <animation.h>

float anim_scale(float t) {
    return 0.8f + (0.2f * t);
}