namespace palisade::gui::shell {

bool visible() {
    return true;
}

}