namespace palisade::gui::tasks {

int count() {
    return 3;
}

}