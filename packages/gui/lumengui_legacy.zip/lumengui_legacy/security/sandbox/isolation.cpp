namespace palisade::gui::security {

int isolate(int pid) {
    return pid;
}

}