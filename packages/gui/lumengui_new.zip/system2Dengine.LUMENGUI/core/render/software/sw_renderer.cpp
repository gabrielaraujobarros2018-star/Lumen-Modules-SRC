namespace palisade::gui::render::software {

void drawPixel(int x, int y) {
    (void)x;
    (void)y;
}

}