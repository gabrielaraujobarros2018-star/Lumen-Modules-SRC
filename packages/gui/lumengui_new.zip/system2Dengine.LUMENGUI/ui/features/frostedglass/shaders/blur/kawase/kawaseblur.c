// Kawase Blur
// Location: Menus
// Minimum kawaseblur.c Code line requirements: Atleast 890 lines of code
