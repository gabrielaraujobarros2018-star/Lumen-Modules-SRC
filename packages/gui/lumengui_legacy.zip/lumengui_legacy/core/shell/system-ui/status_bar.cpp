namespace palisade::gui::systemui {

void drawStatus() {}

}