namespace palisade::gui::scene {

static int nodeCount = 0;

void attachNode() {
    nodeCount++;
}

}