#include "renderer.hpp"

namespace palisade::gui::renderer {

void beginFrame() {}
void endFrame() {}

}