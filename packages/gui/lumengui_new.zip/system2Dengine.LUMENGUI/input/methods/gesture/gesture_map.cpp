namespace palisade::gui::gesture {

int mapGesture(int raw) {
    return raw;
}

}