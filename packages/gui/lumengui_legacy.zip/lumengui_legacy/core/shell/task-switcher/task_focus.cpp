namespace palisade::gui::tasks {

void focus(int id) {
    (void)id;
}

}