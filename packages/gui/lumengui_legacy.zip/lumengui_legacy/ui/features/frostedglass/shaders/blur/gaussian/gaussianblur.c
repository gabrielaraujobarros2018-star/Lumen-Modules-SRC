// Gaussian Blur
// Location: Settings App and Control center
// Minimum gaussianblur.c Code line requirements: Atleast 1300 lines of code