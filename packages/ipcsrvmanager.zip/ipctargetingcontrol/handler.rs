// handler.rs - Updated with IpcTargetingControl for Nexus 6 ARMv7a Lumen OS
// Handles IPC message paging (16kb) + device targeting enforcement.
// Integrates with OSServer stub.

use core::arch::asm;
use core::ptr::{self, NonNull};
use core::slice;
use alloc::string::String;
use alloc::vec::Vec;

use crate::osserver::{OSServer, OSServerConfig, LockType};

const MEM_PAGE_SIZE: usize = 16 * 1024;
const L1_TABLE_BASE: usize = 0x8000_0000;
const NEXUS6_CODENAME: &str = "shamu";
const SYSTEM_UID: u32 = 1000;

#[repr(C, packed)]
struct L1Entry {
    raw: u32,
    type_section: u8,
    tex: u8,
    cacheable: u8,
    bufferable: u8,
}

pub struct IpcPagingHandler {
    targeting_control: IpcTargetingControl,
    osserver: *mut OSServer,
}

pub struct IpcTargetingControl {
    target_device: String,
    allowed_uids: Vec<u32>,
    config: OSServerConfig,
    lock: GlobalLock,
}

struct GlobalLock {
    // ARMv7 LDREX/STREX implementation
    lock_addr: *mut u32,
}

impl GlobalLock {
    pub const fn new() -> Self {
        Self { 
            lock_addr: 0x8000_1000 as *mut u32  // Fixed kernel lock addr
        }
    }
    
    pub fn lock(&self) {
        unsafe {
            asm!(
                "1: ldrex r0, [{lock}]",
                "teq r0, #0",
                "wfene",
                "bne 1b",
                "mov r1, #1",
                "strex r0, r1, [{lock}]",
                "teq r0, #0",
                "bne 1b",
                lock = in(reg) self.lock_addr as u32,
                options(nostack, preserves_flags)
            );
        }
    }
    
    pub fn unlock(&self) {
        unsafe {
            asm!(
                "mov r0, #0",
                "str r0, [{lock}]",
                "dsb",
                "sev",
                lock = in(reg) self.lock_addr as u32,
                options(nostack)
            );
        }
    }
}

impl IpcPagingHandler {
    pub fn new(osserver: *mut OSServer) -> Self {
        let config = unsafe { (*osserver).get_config_values() };
        let targeting = IpcTargetingControl::new(config);
        
        Self { 
            targeting_control: targeting,
            osserver 
        }
    }

    pub fn handle_transaction(
        &mut self, 
        uid: u32, 
        target: &str, 
        data: &[u8]
    ) -> Result<(), &'static str> {
        self.targeting_control.lock.lock();
        
        // Target enforcement
        self.targeting_control.validate_target(uid, target)?;
        
        // UID enforcement
        if !self.targeting_control.allowed_uids.contains(&uid) {
            return Err("UID not authorized");
        }
        
        // Page mapping
        let page_count = (data.len() + MEM_PAGE_SIZE - 1) / MEM_PAGE_SIZE;
        unsafe {
            Self::map_ipc_pages(page_count, target)?;
            Self::copy_to_pages(data);
        }
        
        self.targeting_control.lock.unlock();
        Ok(())
    }

    unsafe fn map_ipc_pages(page_count: usize, target: &str) -> Result<(), &'static str> {
        let l1_table = NonNull::new((L1_TABLE_BASE as *mut L1Entry)).unwrap();
        
        for i in 0..page_count {
            let vaddr = L1_TABLE_BASE + i * MEM_PAGE_SIZE;
            let paddr = vaddr;  // Identity map Nexus 6 kernel
            
            let mut entry: L1Entry = ptr::read(l1_table.as_ptr().add(i));
            entry.type_section = 1;
            entry.tex = 1;
            entry.cacheable = 1;
            entry.bufferable = 1;
            ptr::write(l1_table.as_ptr().add(i), entry);

            // Target-specific TLB flush
            if target.contains(NEXUS6_CODENAME) {
                asm!(
                    "mcr p15, 0, {0}, c7, c5, 1",
                    "mcr p15, 0, {0}, c7, c10, 4",  // Target-specific invalidate
                    "dsb",
                    "isb",
                    in(reg) vaddr as u32,
                    options(nostack, preserves_flags)
                );
            }
        }
        Ok(())
    }

    unsafe fn copy_to_pages(data: &[u8]) {
        let dest = (L1_TABLE_BASE as *mut u8);
        ptr::copy_nonoverlapping(data.as_ptr(), dest, data.len());
    }
}

impl IpcTargetingControl {
    pub fn new(config: OSServerConfig) -> Self {
        Self {
            target_device: config.binder_target,
            allowed_uids: vec![SYSTEM_UID, 1001],  // system + radio
            config,
            lock: GlobalLock::new(),
        }
    }
    
    pub fn validate_target(&mut self, uid: u32, target: &str) -> Result<(), &'static str> {
        if target != self.target_device {
            return Err("Target device mismatch");
        }
        
        // Nexus 6 shamu targeting enforcement
        if !target.contains("shamu") && !target.contains("Nexus 6") {
            return Err("Nexus 6 target required");
        }
        
        Ok(())
    }
    
    pub fn add_allowed_uid(&mut self, uid: u32) {
        self.allowed_uids.push(uid);
    }
}

/// Update entry point with OSServer integration
#[no_mangle]
pub extern "C" fn ipc_paging_handler_init(osserver_ptr: *mut OSServer) {
    unsafe {
        let handler = Box::into_raw(Box::new(IpcPagingHandler::new(osserver_ptr)));
        // Register with binder driver + OSServer
        core::ptr::write_volatile(0x8000_2000 as *mut *mut IpcPagingHandler, handler);
    }
}