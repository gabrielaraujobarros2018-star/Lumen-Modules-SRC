namespace palisade::gui::render::software {

void blit() {}

}