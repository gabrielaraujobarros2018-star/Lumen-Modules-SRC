namespace palisade::gui::protocol::window {

int open() {
    return 1;
}

}