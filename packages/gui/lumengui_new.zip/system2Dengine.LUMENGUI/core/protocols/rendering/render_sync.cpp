namespace palisade::gui::protocol::render {

bool sync() {
    return true;
}

}