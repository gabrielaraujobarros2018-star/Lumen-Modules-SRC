namespace palisade::gui::compositor {

bool isTopmost(int z) {
    return z == 0;
}

}